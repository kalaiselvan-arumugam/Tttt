var validationErrors = [];
var validationRules = [
    { column: 1, regex: /^[A-Za-z ]+$/ },
];

var currentPage = 1;
var pageSize = 100;
var totalPages = 0;
var csvData = [];
var filteredData = [];
var processingStartTime;

$('#csvFile').on('change', function(e) {
    const file = e.target.files[0];
    if (file) {
        $('#uploadedFileName').text(file.name);
        $('#searchInput').prop('disabled', true);
        $(".table-footer-container").addClass("hide");
        $('.table-responsive').removeClass('pagination');
        $('.sc-data-table').removeClass('pagination');
        $('#tableHeader').empty();
        $('#tableBody').empty();
        $('#submit').attr('disabled', true);
        processingStartTime = performance.now();
        processCSV(file);
    }
});

async function processCSV(file) {
  $(".progress-container").addClass("active");
    try {
        $('.error').text('');
        csvData = [];
        validationErrors = [];
        let header = null;
        let buffer = '';
        let bytesRead = 0;
        let chunkSize = 1024 * 1024;
        let startTime = performance.now();

        for (let offset = 0; offset < file.size; offset += chunkSize) {
            const chunk = file.slice(offset, offset + chunkSize);
            const textChunk = await readChunk(chunk);
            buffer += textChunk;
            
            const rows = buffer.split(/\r?\n/);
            buffer = rows.pop() || '';

            if (!header) {
                header = parseCSVRow(rows.shift());
                createHeaders(header);
            }

            await processRowsInBatches(rows, header.length);
            
            bytesRead += chunkSize;
            updateProgress(Math.min(bytesRead / file.size * 100, 100));
        }

        filteredData = csvData.map((row, index) => ({ row, originalIndex: index }));
        totalPages = Math.ceil(filteredData.length / pageSize);
        setupPagination();
        console.log(`Total processing time: ${performance.now() - startTime}ms`);
        let anyErrors = validationErrors.some(errors => errors.length > 0);
        if (!anyErrors) {
           $('#submit').attr('disabled', false);
        }

        // validationErrors.forEach((errors, index) => {
        //     if (errors.length > 0) {
        //         console.log(`Row ${index + 1} errors:`,  errors.map(e => `Column ${e.column + 1} failed ${e.rule}`).join(', '));
        //     }
        // });

    } catch (error) {
        handleError(error.message);
    }
}

function performSearch(searchTerm) {
    searchTerm = searchTerm.trim().toLowerCase();
    if (!searchTerm) {
        filteredData = csvData.map((row, index) => ({ row, originalIndex: index }));
    } else {
        filteredData = csvData
            .map((row, index) => ({ row, originalIndex: index }))
            .filter(item => 
                item.row.some(cell => 
                    cell.toLowerCase().includes(searchTerm)
                )
            );
    }
    currentPage = 1;
    totalPages = Math.ceil(filteredData.length / pageSize);
    setupPagination();
}

function debounce(func, wait) {
    let timeout;
    return function(...args) {
        clearTimeout(timeout);
        timeout = setTimeout(() => func.apply(this, args), wait);
    };
}

$('#searchInput').on('input', debounce(function() {
    performSearch($(this).val());
}, 300));

function renderCurrentPage() {
    const startTime = performance.now();
    const start = (currentPage - 1) * pageSize;
    const end = start + pageSize;
    const pageData = filteredData.slice(start, end);
    
    const fragment = document.createDocumentFragment();
    pageData.forEach((item, index) => {
        const $tr = $('<tr>');
        const originalIndex = item.originalIndex;
        const errors = validationErrors[originalIndex] || [];
        
        item.row.forEach((cell, colIndex) => {
            const isInvalid = errors.some(e => e.column === colIndex);
            const $td = $('<td>')
                .text(cell)
                .toggleClass('invalid-cell', isInvalid)
                .attr('title', isInvalid ? 
                    `Row ${originalIndex + 1} validation failed` : '');
            $tr.append($td);
        });
        
        fragment.appendChild($tr[0]);
    });

    $('#tableBody').empty().append(fragment);
    $('#pageInfo').text(`Page ${currentPage} of ${totalPages}`);
    console.log(`Page rendered in ${performance.now() - startTime}ms`);
    $('#searchInput').prop('disabled', false);
    $(".table-footer-container").removeClass("hide");
    $('.table-responsive').addClass('pagination');
    $('.sc-data-table').addClass('pagination');



}

function readChunk(chunk) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsText(chunk);
    });
}

async function processRowsInBatches(rows, expectedColumns, batchSize = 1000) {
    const parserStart = performance.now();
    for (let i = 0; i < rows.length; i += batchSize) {
        const batch = rows.slice(i, i + batchSize);
        batch.forEach(row => {
            const parsed = parseCSVRow(row);
            if (parsed.length !== expectedColumns) {
                throw new Error('CSV structure mismatch');
            }
            const errors = validateRow(parsed);
            if (errors.length > 0) {
                validationErrors.push(errors);
            } else {
                validationErrors.push([]);
            }
            csvData.push(parsed);
        });
        await new Promise(resolve => setTimeout(resolve, 0));
    }
    //console.log(`Batch processed in ${performance.now() - parserStart}ms`);
}

function validateRow(row) {
    const errors = [];
    for (const rule of validationRules) {
        const value = row[rule.column] || '';
        if (!rule.regex.test(value)) {
            errors.push({
                column: rule.column,
                value: value,
                rule: rule.regex.toString()
            });
        }
    }
    return errors;
}

function parseCSVRow(row) {
    const result = [];
    let current = '';
    let inQuotes = false;

    for (let char of row) {
        if (char === '"') {
            inQuotes = !inQuotes;
        } else if (char === ',' && !inQuotes) {
            result.push(current.trim());
            current = '';
        } else {
            current += char;
        }
    }
    result.push(current.trim());
    return result;
}

function createHeaders(headerData) {
    const $headerRow = $('<tr>');
    headerData.forEach(col => $headerRow.append($('<th>').text(col)));
    $('#tableHeader').empty().append($headerRow);
    $(".no-content-container").addClass("hide");
}

function updateProgress(percent) {
    $('.progress-fill').css('width', `${percent}%`);
}

function setupPagination() {
    $('#prevPage').prop('disabled', currentPage <= 1);
    $('#nextPage').prop('disabled', currentPage >= totalPages);
    if(currentPage <= 1){
      $('#prevPage').removeClass('active');
    } else{
      $('#prevPage').addClass('active');
    }
    if(currentPage >= totalPages){
      $('#nextPage').removeClass('active');
    } else{
      $('#nextPage').addClass('active');
    }
    renderCurrentPage();
}

$('#prevPage').click(() => {
    if (currentPage > 1) {
        currentPage--;
        setupPagination();
    }
});

$('#nextPage').click(() => {
    if (currentPage < totalPages) {
        currentPage++;
        setupPagination();
    }
});

function handleError(message) {
    $('.error').text(message);
    $('.progress-fill').css('width', '0%');
    csvData = [];
    filteredData = [];
}