package com.ks.auth.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.SecretKey;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.ks.auth.config.AppConfig;
import com.ks.auth.domain.AuthenticationRequest;
import com.ks.auth.domain.TokenValidationRequest;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

@WebMvcTest(AuthController.class)
@AutoConfigureMockMvc(addFilters = false)
class AuthControllerTest {

    @Autowired
    private MockMvc mockMvc;

    private Gson gson = new Gson();
    private JsonObject validUser;

    @BeforeEach
    public void setup() {
        validUser = AppConfig.getConfig().getAsJsonObject("auth")
                            .getAsJsonArray("users")
                            .get(0).getAsJsonObject();
    }

    @Test
    void testAuthenticateSuccess() throws Exception {
        AuthenticationRequest request = new AuthenticationRequest();
        request.setClient_id(validUser.get("client_id").getAsString());
        request.setClient_secret(validUser.get("client_secret").getAsString());
        request.setOrgid(validUser.get("orgid").getAsString());
        request.setUniqueid(validUser.get("uniqueid").getAsString());
        String jsonRequest = gson.toJson(request);
        mockMvc.perform(post("/core/oauth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRequest))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.access_token").exists())
                .andExpect(jsonPath("$.expires_in").exists());
    }

    @Test
    void testAuthenticateMissingFields() throws Exception {
        String jsonRequest = "{}";
        mockMvc.perform(post("/core/oauth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRequest))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("Missing credentials in the request"));
    }

    @Test
    void testAuthenticateInvalidCredentials() throws Exception {
        AuthenticationRequest request = new AuthenticationRequest();
        request.setClient_id("invalid");
        request.setClient_secret("invalid");
        request.setOrgid("invalid");
        request.setUniqueid("invalid");
        String jsonRequest = gson.toJson(request);
        mockMvc.perform(post("/core/oauth/token")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRequest))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value("Invalid credentials"));
    }

    @Test
    void testValidateTokenSuccess() throws Exception {
        Map<String, Object> claims = new HashMap<>();
        claims.put("uniqueid", validUser.get("uniqueid").getAsString());
        String secret = AppConfig.getConfig().getAsJsonObject("jwtConfig").get("secret").getAsString();
        SecretKey key = Keys.hmacShaKeyFor(secret.getBytes());
        long now = System.currentTimeMillis();
        Date exp = new Date(now + 60000);
        String token = Jwts.builder()
                .setClaims(claims)
                .setSubject(validUser.get("client_id").getAsString())
                .setIssuedAt(new Date(now))
                .setExpiration(exp)
                .signWith(key, SignatureAlgorithm.HS256)
                .compact();
        TokenValidationRequest request = new TokenValidationRequest();
        request.setAccess_token(token);
        String jsonRequest = gson.toJson(request);
        mockMvc.perform(post("/core/oauth/validateToken")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRequest))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Token is valid"))
                .andExpect(jsonPath("$.expires_at").exists());
    }

    @Test
    void testValidateTokenMissing() throws Exception {
        String jsonRequest = "{}";
        mockMvc.perform(post("/core/oauth/validateToken")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRequest))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.message").value("Token is missing from the request"));
    }

    @Test
    void testValidateTokenInvalid() throws Exception {
        TokenValidationRequest request = new TokenValidationRequest();
        request.setAccess_token("invalid.token.here");
        String jsonRequest = gson.toJson(request);
        mockMvc.perform(post("/core/oauth/validateToken")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(jsonRequest))
                .andExpect(status().isUnauthorized())
                .andExpect(jsonPath("$.message").value("Invalid or expired token"));
    }
}