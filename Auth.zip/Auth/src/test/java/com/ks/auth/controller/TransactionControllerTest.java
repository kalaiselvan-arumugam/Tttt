package com.ks.auth.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ks.auth.service.SftpService;
import com.ks.auth.service.TransactionService;

class TransactionControllerTest {

    private MockMvc mockMvc;

    @Mock
    private SftpService sftpService;

    @Mock
    private TransactionService transactionService;

    @InjectMocks
    private TransactionController transactionController;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        mockMvc = MockMvcBuilders.standaloneSetup(transactionController).build();
    }

    @Test
    void testCreateTransaction_Success() throws Exception {
        // Arrange
        String requestBody = "{\"ext_doc_id\": \"12345\"}";
        JsonObject requestJson = JsonParser.parseString(requestBody).getAsJsonObject();

        when(sftpService.copyFromSftp("12345")).thenReturn(true);

        JsonObject authResponse = new JsonObject();
        authResponse.addProperty("access_token", "valid-token");
        when(transactionService.getAuthenticationToken(any())).thenReturn(authResponse);

        JsonObject transactionResponse = new JsonObject();
        transactionResponse.addProperty("status", HttpStatus.OK.value());
        transactionResponse.addProperty("responseBody", "Transaction created successfully");
        when(transactionService.saveTransaction(eq("test-uid"), eq("valid-token"), eq(requestJson)))
                .thenReturn(transactionResponse);

        // Act & Assert
        mockMvc.perform(post("/transaction/document/tts")
                        .header("User-Agent", "test-uid")
                        .content(requestBody)
                        .contentType("application/json"))
                .andExpect(status().isOk())
                .andExpect(content().json("{\"message\":\"Transaction created successfully\"}"));

        verify(sftpService, times(1)).copyFromSftp("12345");
        verify(transactionService, times(1)).getAuthenticationToken(any());
        verify(transactionService, times(1)).saveTransaction(eq("test-uid"), eq("valid-token"), eq(requestJson));
    }

    @Test
    void testCreateTransaction_SftpCopyFails() throws Exception {
        // Arrange
        String requestBody = "{\"ext_doc_id\": \"12345\"}";

        when(sftpService.copyFromSftp("12345")).thenReturn(false);

        // Act & Assert
        mockMvc.perform(post("/transaction/document/tts")
                        .header("User-Agent", "test-uid")
                        .content(requestBody)
                        .contentType("application/json"))
                .andExpect(status().isInternalServerError())
                .andExpect(content().json("{\"message\":\"Internal server error\"}"));

        verify(sftpService, times(1)).copyFromSftp("12345");
        verify(transactionService, never()).getAuthenticationToken(any());
        verify(transactionService, never()).saveTransaction(any(), any(), any());
    }

    @Test
    void testCreateTransaction_AuthenticationFails() throws Exception {
        // Arrange
        String requestBody = "{\"ext_doc_id\": \"12345\"}";

        when(sftpService.copyFromSftp("12345")).thenReturn(true);
        when(transactionService.getAuthenticationToken(any())).thenReturn(null);

        // Act & Assert
        mockMvc.perform(post("/transaction/document/tts")
                        .header("User-Agent", "test-uid")
                        .content(requestBody)
                        .contentType("application/json"))
                .andExpect(status().isInternalServerError())
                .andExpect(content().json("{\"message\":\"Internal server error\"}"));

        verify(sftpService, times(1)).copyFromSftp("12345");
        verify(transactionService, times(1)).getAuthenticationToken(any());
        verify(transactionService, never()).saveTransaction(any(), any(), any());
    }

    @Test
    void testCreateTransaction_SaveTransactionFails() throws Exception {
        // Arrange
        String requestBody = "{\"ext_doc_id\": \"12345\"}";

        when(sftpService.copyFromSftp("12345")).thenReturn(true);

        JsonObject authResponse = new JsonObject();
        authResponse.addProperty("access_token", "valid-token");
        when(transactionService.getAuthenticationToken(any())).thenReturn(authResponse);

        when(transactionService.saveTransaction(any(), any(), any())).thenReturn(null);

        // Act & Assert
        mockMvc.perform(post("/transaction/document/tts")
                        .header("User-Agent", "test-uid")
                        .content(requestBody)
                        .contentType("application/json"))
                .andExpect(status().isInternalServerError())
                .andExpect(content().json("{\"message\":\"Internal server error\"}"));

        verify(sftpService, times(1)).copyFromSftp("12345");
        verify(transactionService, times(1)).getAuthenticationToken(any());
        verify(transactionService, times(1)).saveTransaction(any(), any(), any());
    }

    @Test
    void testCreateTransaction_ExceptionHandling() throws Exception {
        // Arrange
        String requestBody = "{\"ext_doc_id\": \"12345\"}";

        when(sftpService.copyFromSftp("12345")).thenThrow(new RuntimeException("Unexpected error"));

        // Act & Assert
        mockMvc.perform(post("/transaction/document/tts")
                        .header("User-Agent", "test-uid")
                        .content(requestBody)
                        .contentType("application/json"))
                .andExpect(status().isInternalServerError())
                .andExpect(content().json("{\"message\":\"Internal server error\"}"));

        verify(sftpService, times(1)).copyFromSftp("12345");
        verify(transactionService, never()).getAuthenticationToken(any());
        verify(transactionService, never()).saveTransaction(any(), any(), any());
    }
}