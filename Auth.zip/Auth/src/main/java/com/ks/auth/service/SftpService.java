package com.ks.auth.service;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Paths;
import java.security.MessageDigest;
import java.util.Vector;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.io.FileUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.google.gson.JsonObject;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
import com.jcraft.jsch.SftpException;
import com.ks.auth.config.AppConfig;
import com.ks.auth.util.StackTrace;

@Service
public class SftpService {
    private static final Logger log = LogManager.getLogger(SftpService.class);
    
    private static final JsonObject authConfig = AppConfig.getConfig();
    private static final JsonObject config = authConfig.getAsJsonObject("sftpConfig");
    

    public boolean copyFromSftp(String remoteDir) {
        ChannelSftp channel = null;
        try {
            channel = connect();
            if (channel == null) return false;
            String remotePath = combineRemotePaths(config.get("remoteBasePath").getAsString(), remoteDir);
            String localPath = Paths.get(config.get("localBasePath").getAsString(), remoteDir).toString();
            boolean success = copyDirectoryFrom(channel, remotePath, localPath);
            if (success && config.get("deleteSourceDirctory").getAsBoolean()) {
                log.info("Deleting remote source directory: {}", remotePath);
                deleteRemoteDirectory(channel, remotePath);
            }
            return success;
        } catch (Exception ex) {
            log.error("Error in copyFromSftp: {}", StackTrace.getMessage(ex));
            return false;
        } finally {
        	if(channel != null) {
        		disconnect(channel);
        	}
        }
    }

    public boolean copyToSftp(String localDir) {
        ChannelSftp channel = null;
        try {
            channel = connect();
            if (channel == null) return false;
            String localPath = Paths.get(config.get("localBasePath").getAsString(), localDir).toString();
            String remotePath = combineRemotePaths(config.get("remoteBasePath").getAsString(), localDir);
            boolean success = copyDirectoryTo(channel, localPath, remotePath);
            if (success && config.get("deleteSourceDirctory").getAsBoolean()) {
                log.info("Deleting local source directory: {}", localPath);
                deleteLocalDirectory(localPath);
            }
            return success;
        } catch (Exception ex) {
            log.error("Error in copyToSftp: {}", StackTrace.getMessage(ex));
            return false;
        } finally {
            disconnect(channel);
        }
    }

    private ChannelSftp connect() {
        try {
            JSch jsch = new JSch();
            jsch.setKnownHosts(config.get("knownHosts").getAsString());
            Session session = jsch.getSession(config.get("userName").getAsString(), config.get("host").getAsString(), config.get("port").getAsInt());
            session.setPassword(config.get("password").getAsString());
            session.setConfig("StrictHostKeyChecking", config.get("strictHostKeyChecking").getAsString());
            session.connect(config.get("sessionTimeout").getAsInt());
            Channel channel = session.openChannel("sftp");
            channel.connect(config.get("channelTimeout").getAsInt());
            return (ChannelSftp) channel;
        } catch (Exception ex) {
            log.error("SFTP connection error: {}", StackTrace.getMessage(ex));
            return null;
        }
    }

    private void disconnect(ChannelSftp channel) {
        if (channel != null) {
            try {
                channel.disconnect();
                if (channel.getSession() != null) {
                    channel.getSession().disconnect();
                }
            } catch (Exception ex) {
                log.error("Disconnection error: {}", StackTrace.getMessage(ex));
            }
        }
    }

    private boolean copyDirectoryFrom(ChannelSftp channel, String remoteDir, String localDir) {
        try {
            FileUtils.forceMkdir(new File(localDir));
            Vector<ChannelSftp.LsEntry> entries = channel.ls(remoteDir);
            boolean allSuccess = true;
            for (ChannelSftp.LsEntry entry : entries) {
                String filename = entry.getFilename();
                if (filename.equals(".") || filename.equals("..")) continue;
                String remotePath = combineRemotePaths(remoteDir, filename);
                String localPath = Paths.get(localDir, filename).toString();
                if (entry.getAttrs().isDir()) {
                    allSuccess &= copyDirectoryFrom(channel, remotePath, localPath);
                } else {
                    allSuccess &= copyFileFrom(channel, remotePath, localPath);
                }
            }
            return allSuccess;
        } catch (Exception ex) {
            log.error("Error copying directory from SFTP: {}", StackTrace.getMessage(ex));
            return false;
        }
    }

    private boolean copyFileFrom(ChannelSftp channel, String remotePath, String localPath) {
        try (InputStream is = channel.get(remotePath);
             OutputStream os = FileUtils.openOutputStream(new File(localPath))) {
            MessageDigest md = getDigest();
            byte[] buffer = new byte[8192];
            int bytesRead;
            while ((bytesRead = is.read(buffer)) != -1) {
                os.write(buffer, 0, bytesRead);
                md.update(buffer, 0, bytesRead);
            }
            String remoteHash = bytesToHex(md.digest());
            String localHash = calculateHash(new File(localPath));
            log.info("Downloaded: {} | Checksum: {} | Integrity: {}", remotePath, remoteHash, remoteHash.equals(localHash) ? "PASS" : "FAIL");
            return remoteHash.equals(localHash);
        } catch (Exception ex) {
            log.error("Error downloading file: {}", StackTrace.getMessage(ex));
            return false;
        }
    }

    private boolean copyDirectoryTo(ChannelSftp channel, String localDir, String remoteDir) {
        try {
            if(!mkdirs(channel, remoteDir)) {
            	return false;
            }
            File localDirFile = new File(localDir);
            File[] files = localDirFile.listFiles();
            if (files == null) return false;
            boolean allSuccess = true;
            for (File file : files) {
                String remotePath = combineRemotePaths(remoteDir, file.getName());
                String localPath = file.getAbsolutePath();
                if (file.isDirectory()) {
                    allSuccess &= copyDirectoryTo(channel, localPath, remotePath);
                } else {
                    allSuccess &= copyFileTo(channel, localPath, remotePath);
                }
            }
            return allSuccess;
        } catch (Exception ex) {
            log.error("Error copying directory to SFTP: {}", StackTrace.getMessage(ex));
            return false;
        }
    }

    private boolean copyFileTo(ChannelSftp channel, String localPath, String remotePath) {
        try (InputStream is = FileUtils.openInputStream(new File(localPath));
             OutputStream os = channel.put(remotePath)) {
            MessageDigest md = getDigest();
            byte[] buffer = new byte[8192];
            int bytesRead;
            while ((bytesRead = is.read(buffer)) != -1) {
                os.write(buffer, 0, bytesRead);
                md.update(buffer, 0, bytesRead);
            }
            String sentHash = bytesToHex(md.digest());
            String localHash = calculateHash(new File(localPath));
            log.info("Uploaded: {} | Checksum: {} | Integrity: {}", remotePath, sentHash,
                    sentHash.equals(localHash) ? "PASS" : "FAIL");
            return sentHash.equals(localHash);
        } catch (Exception ex) {
            log.error("Error uploading file: {}", StackTrace.getMessage(ex));
            return false;
        }
    }

    // Helper methods
    private String bytesToHex(byte[] bytes) {
        StringBuilder hexString = new StringBuilder();
        for (byte b : bytes) {
            String hex = Integer.toHexString(0xff & b);
            if (hex.length() == 1) hexString.append('0');
            hexString.append(hex);
        }
        return hexString.toString();
    }

    private MessageDigest getDigest() {
        switch (config.get("integrityCheck").getAsString().toUpperCase()) {
            case "SHA-256":
                return DigestUtils.getSha256Digest();
            case "MD5":
                return DigestUtils.getMd5Digest();
            default:
                throw new IllegalArgumentException("Unsupported hash algorithm");
        }
    }

    private String calculateHash(File file) throws IOException {
        try (InputStream is = FileUtils.openInputStream(file)) {
            return switch (config.get("integrityCheck").getAsString().toUpperCase()) {
                case "SHA-256" -> DigestUtils.sha256Hex(is);
                case "MD5" -> DigestUtils.md5Hex(is);
                default -> "N/A";
            };
        }
    }

    private String combineRemotePaths(String base, String addition) {
        String combined = base.replaceAll("/+$", "") + "/" + addition.replaceAll("^/+", "");
        return combined.replaceAll("/+", "/");
    }

	private boolean mkdirs(ChannelSftp channel, String path) throws SftpException {
		String[] folders = path.split("/");
		StringBuilder currentPath = new StringBuilder();
		try {
			for (String folder : folders) {
				if (folder.isEmpty())
					continue;
				currentPath.append("/").append(folder);
				String dirPath = currentPath.toString();
				channel.mkdir(dirPath);
			}
			return true;
		} catch (Exception ex) {
			log.error("Error creating directory: {}", StackTrace.getMessage(ex));
			return false;
		}
	}

	private boolean deleteRemoteDirectory(ChannelSftp channel, String path) {
        try {
            Vector<ChannelSftp.LsEntry> entries = channel.ls(path);
            for (ChannelSftp.LsEntry entry : entries) {
                String filename = entry.getFilename();
                if (filename.equals(".") || filename.equals("..")) continue;
                String filepath = combineRemotePaths(path, filename);
                if (entry.getAttrs().isDir()) {
                    deleteRemoteDirectory(channel, filepath);
                } else {
                    channel.rm(filepath);
                }
            }
            channel.rmdir(path);
            return true;
        } catch (SftpException ex) {
            log.error("Error deleting remote directory: {}", StackTrace.getMessage(ex));
            return false;
        }
    }

	private boolean deleteLocalDirectory(String path) {
        try {
            File directory = new File(path);
            if (directory.exists()) {
                FileUtils.deleteDirectory(directory);
                return true;
            }
            return false;
        } catch (Exception ex) {
            log.error("Error deleting local directory: {}", StackTrace.getMessage(ex));
            return false;
        }
    }
}