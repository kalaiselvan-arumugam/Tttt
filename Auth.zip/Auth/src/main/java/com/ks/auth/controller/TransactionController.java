package com.ks.auth.controller;

import java.time.Duration;
import java.time.Instant;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.ks.auth.config.AppConfig;
import com.ks.auth.domain.GenericResponse;
import com.ks.auth.service.SftpService;
import com.ks.auth.service.TransactionService;
import com.ks.auth.util.StackTrace;

@RestController
@RequestMapping("/transaction/document")
public class TransactionController {
	
	private static final Logger logger = LogManager.getLogger(TransactionController.class);
	private static final JsonObject config = AppConfig.getConfig();
    private static final JsonObject rmConfig = config.getAsJsonObject("rm");

    private final SftpService sftpService;
    private final TransactionService transactionService;

    public TransactionController(SftpService sftpService, TransactionService transactionService) {
        this.sftpService = sftpService;
        this.transactionService = transactionService;
    }
	
	@PostMapping("/tts")
	public ResponseEntity<?> createTrasaction(@RequestHeader("User-Agent") String uid, @RequestBody String requestBody) {
		Instant start = Instant.now();
		try {
			JsonObject request = JsonParser.parseString(requestBody).getAsJsonObject();
			
			if(!sftpService.copyFromSftp(request.get("ext_doc_id").getAsString())) {
				logger.error("Unable to copy/transfer the files from remote location");
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new GenericResponse("Internal server error"));
			}
			
			JsonObject authenticationResponse = transactionService.getAuthenticationToken(rmConfig.get("authentication").getAsJsonObject()); 
			if(authenticationResponse == null){
				logger.error("Unable to get authentication details from rm");
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new GenericResponse("Internal server error"));
			}
			
			JsonObject transactionResponse = transactionService.saveTransaction(uid, authenticationResponse.get("access_token").getAsString(), request);
			if(transactionResponse == null){
				logger.error("Unable to get transaction details from rm");
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new GenericResponse("Internal server error"));
			}
			return ResponseEntity.status(transactionResponse.get("status").getAsInt()).body(new GenericResponse(transactionResponse.get("responseBody").getAsString()));
			
		} catch (Exception ex) {
			logger.error("Exception processing createTransaction request : {} ms", StackTrace.getMessage(ex));
			return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new GenericResponse("Internal server error"));
		} finally {
			Duration timeElapsed = Duration.between(start, Instant.now());
			logger.info("Time taken complete the createTrasaction request : {}", timeElapsed.toMillis());
		}
	}

}