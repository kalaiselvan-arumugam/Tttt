package com.ks.auth.controller;

import java.util.HashMap;
import java.util.Map;
import java.util.stream.StreamSupport;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.ks.auth.config.AppConfig;
import com.ks.auth.domain.AuthResponse;
import com.ks.auth.domain.AuthenticationRequest;
import com.ks.auth.domain.GenericResponse;
import com.ks.auth.domain.TokenValidationRequest;
import com.ks.auth.util.JwtUtil;
import com.ks.auth.util.StackTrace;

import io.jsonwebtoken.Claims;

@RestController
@RequestMapping("/core/oauth")
public class AuthController {
    private static final Logger logger = LogManager.getLogger(AuthController.class);
    private static final JsonObject config = AppConfig.getConfig();
    private static final JsonObject authConfig = config.getAsJsonObject("auth");
    
    private final JwtUtil jwtUtil;

    public AuthController(JwtUtil jwtUtil) {
        this.jwtUtil = jwtUtil;
    }
    
    
    
    @PostMapping("/token")
    public ResponseEntity<?> authenticate(@RequestBody AuthenticationRequest request) {
        try {
            if (request.getClient_id() == null || request.getClient_secret() == null ||
                request.getOrgid() == null || request.getUniqueid() == null) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(new GenericResponse("Missing credentials in the request"));
            }
            boolean isValid = StreamSupport.stream(authConfig.getAsJsonArray("users").spliterator(), false)
            	    .map(JsonElement::getAsJsonObject)
            	    .anyMatch(user ->
            	        user.get("client_id").getAsString().equals(request.getClient_id()) &&
            	        user.get("client_secret").getAsString().equals(request.getClient_secret()) &&
            	        user.get("orgid").getAsString().equals(request.getOrgid()) &&
            	        user.get("uniqueid").getAsString().equals(request.getUniqueid()));

            if (!isValid) {
            	logger.warn("An attempt to generate an authentication token was made using invalid credentials.");
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(new GenericResponse("Invalid credentials"));
            }
            Map<String, Object> claims = new HashMap<>();
            claims.put("uniqueid", request.getUniqueid());
            Map<String, Object> tokenData = jwtUtil.generateToken(claims, request.getClient_id());
            if (tokenData.containsKey("error")) {
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new GenericResponse("Token generation failed"));
            }
            AuthResponse authResponse = new AuthResponse((String) tokenData.get("access_token"), (Long) tokenData.get("expires_in"));
            return ResponseEntity.ok(authResponse);
        } catch (Exception ex) {
            logger.error("Exception in /authenticate: {}", StackTrace.getMessage(ex));
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new GenericResponse("Internal server error"));
        }
    }

    @PostMapping("/validateToken")
    public ResponseEntity<?> validateToken(@RequestBody TokenValidationRequest request) {
        try {
            if (request.getAccess_token() == null || request.getAccess_token().isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new GenericResponse("Token is missing from the request"));
            }
            Claims claims = jwtUtil.validateToken(request.getAccess_token());
            if (claims == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(new GenericResponse("Invalid or expired token"));
            }
            Map<String, Object> result = new HashMap<>();
            result.put("message", "Token is valid");
            result.put("expires_at", claims.getExpiration().getTime());
            return ResponseEntity.ok(result);
        } catch (Exception ex) {
            logger.error("Exception in /validateToken: {}", StackTrace.getMessage(ex));
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new GenericResponse("Internal server error"));
        }
    }

    @PostMapping("/demo")
    public ResponseEntity<?> demo(@RequestBody TokenValidationRequest request) {
        try {
        	 if (request.getAccess_token() == null || request.getAccess_token().isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(new GenericResponse("Token is missing"));
            }
        	 
            Claims claims = jwtUtil.validateToken(request.getAccess_token());
            if (claims == null) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(new GenericResponse("Invalid or expired token"));
            }
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Access granted to protected resource");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Exception in /demo: {}", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(new GenericResponse("Internal server error"));
        }
    }
}
