package com.ks.auth.exception;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.ks.auth.domain.GenericResponse;

import jakarta.servlet.http.HttpServletRequest;

@RestControllerAdvice
public class GlobalExceptionHandler {
    private static final Logger logger = LogManager.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(HttpMessageNotReadableException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public GenericResponse handleInvalidJson(HttpMessageNotReadableException ex, HttpServletRequest request) {
        logger.error("Invalid JSON syntax: " + ex.getMessage());
        return new GenericResponse("Invalid request body. Please check your JSON syntax.");
    }

    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public GenericResponse handleGeneralException(Exception ex, HttpServletRequest request) {
        logger.error("Unhandled exception: " + ex.getMessage());
        return new GenericResponse("Internal server error");
    }
}
