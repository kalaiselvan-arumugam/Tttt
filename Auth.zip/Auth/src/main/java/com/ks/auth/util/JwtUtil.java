package com.ks.auth.util;

import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.crypto.SecretKey;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Component;

import com.google.gson.JsonObject;
import com.ks.auth.config.AppConfig;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;


@Component
public class JwtUtil {
	
    private static final Logger logger = LogManager.getLogger(JwtUtil.class);
    private static final JsonObject jwtConfig = AppConfig.getConfig().getAsJsonObject("jwtConfig");
    private static final String SECRET = jwtConfig.get("secret").getAsString();
    private static final long EXPIRES_IN = jwtConfig.get("expiresIn").getAsLong() * 1000; // convert to millis
    private static final SecretKey secretKey = Keys.hmacShaKeyFor(SECRET.getBytes(StandardCharsets.UTF_8));


    public Map<String, Object> generateToken(Map<String, Object> claims, String subject) {
        try {
            long now = System.currentTimeMillis();
            Date expiryDate = new Date(now + EXPIRES_IN);
            String token = Jwts.builder()
                    .setClaims(claims)
                    .setSubject(subject)
                    .setIssuedAt(new Date(now))
                    .setExpiration(expiryDate)
                    .signWith(secretKey, SignatureAlgorithm.HS256)
                    .compact();

            Map<String, Object> response = new HashMap<>();
            response.put("access_token", token);
            response.put("expires_in", EXPIRES_IN / 1000);
            return response;
        } catch (Exception e) {
            logger.error("Error generating token: {}" , e.getMessage());
            Map<String, Object> response = new HashMap<>();
            response.put("error", "Token generation failed");
            return response;
        }
    }

    public Claims validateToken(String token) {
        try {
            return Jwts.parserBuilder()
                    .setSigningKey(secretKey)
                    .build()
                    .parseClaimsJws(token)
                    .getBody();
        } catch (Exception e) {
            logger.error("Token validation error: {}", e.getMessage());
            return null;
        }
    }
}