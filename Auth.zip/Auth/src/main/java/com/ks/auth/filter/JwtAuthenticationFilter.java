package com.ks.auth.filter;

import java.io.IOException;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import com.google.gson.Gson;
import com.ks.auth.domain.GenericResponse;
import com.ks.auth.util.JwtUtil;

import io.jsonwebtoken.Claims;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class JwtAuthenticationFilter implements Filter {

    private static final Logger logger = LogManager.getLogger(JwtAuthenticationFilter.class);
    private static final Gson gson = new Gson();

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        String path = httpRequest.getRequestURI();
        logger.info("Processing request for path: {}", path);

        if ("/core/oauth/token".equals(path)) {
            chain.doFilter(request, response);  // Skip authentication for the login endpoint.
            return;
        }

        // Extract headers.
        String authHeader = httpRequest.getHeader("Authorization");
        String headerUniqueId = httpRequest.getHeader("uid");
        
        // Validate headers.
        if (authHeader == null || !authHeader.startsWith("Bearer ") ||
            headerUniqueId == null || headerUniqueId.isEmpty()) {
            logger.warn("Unauthorized access: Missing or invalid Authorization or UniqueId header");
            httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            httpResponse.getWriter().write(
                    gson.toJson(new GenericResponse("Unauthorized access: Authentication token (in Authorization header) and uniqueId header are required"))
            );
            return;
        }

        String token = authHeader.substring(7);
        logger.debug("Extracted JWT token: {}", token);

        // Validate the token.
        Claims claims = new JwtUtil().validateToken(token);
        if (claims == null) {
            logger.warn("Invalid or expired authentication token");
            httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            httpResponse.getWriter().write(
                    gson.toJson(new GenericResponse("Invalid or expired authentication token"))
            );
            return;
        }

        logger.info("JWT token validated successfully");

        // Verify that the uniqueId in the token matches the header value.
        String tokenUniqueId = claims.get("uniqueid", String.class);
        logger.debug("UniqueId from token: {}, UniqueId from header: {}", tokenUniqueId, headerUniqueId);

        if (!headerUniqueId.equals(tokenUniqueId)) {
            logger.warn("Unauthorized access: UniqueId header does not match authentication token");
            httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            httpResponse.getWriter().write(
                    gson.toJson(new GenericResponse("Unauthorized access: UniqueId header does not match authentication token"))
            );
            return;
        }

        logger.info("UniqueId validation successful");

        logger.info("All validations passed. Proceeding with the request.");
        chain.doFilter(request, response);
    }
}