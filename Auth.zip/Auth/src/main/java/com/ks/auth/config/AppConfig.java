package com.ks.auth.config;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.InputStream;
import java.io.InputStreamReader;

public class AppConfig {
	
	private AppConfig() {
		
	}
	
    private static final Logger logger = LogManager.getLogger(AppConfig.class);
    private static JsonObject config;

    static {
        try (InputStream is = AppConfig.class.getClassLoader().getResourceAsStream("config.json");
             InputStreamReader reader = new InputStreamReader(is)) {
            Gson gson = new Gson();
            config = gson.fromJson(reader, JsonObject.class);
            logger.info("Configuration loaded successfully.");
        } catch (Exception e) {
            logger.error("Failed to load configuration: {}", e.getMessage());
            System.exit(1); // Terminate if config is not loaded.
        }
    }

    public static JsonObject getConfig() {
        return config;
    }
}
