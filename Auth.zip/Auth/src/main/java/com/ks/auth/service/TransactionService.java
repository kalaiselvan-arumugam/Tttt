package com.ks.auth.service;

import java.io.File;
import java.io.IOException;
import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;
import java.security.cert.CertificateException;

import javax.net.ssl.SSLContext;

import org.apache.http.HttpEntity;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.NoopHostnameVerifier;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.ssl.SSLContextBuilder;
import org.apache.http.ssl.SSLContexts;
import org.apache.http.util.EntityUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.ks.auth.config.AppConfig;
import com.ks.auth.util.StackTrace;

@Service
public class TransactionService {
	
	private static final Logger logger = LogManager.getLogger(TransactionService.class);
	private static final JsonObject config = AppConfig.getConfig();
    private static final JsonObject rmConfig = config.getAsJsonObject("rm");
	
    public JsonObject getAuthenticationToken(JsonObject requestBody) {
        CloseableHttpClient httpclient = null;
        CloseableHttpResponse response = null; 
        String responseBody = null;
        try {
            httpclient = validateSSL(httpclient);
            if (httpclient == null) {
               logger.error("HTTP client is null or invalid");
               return null;
            }
            HttpPost httpPost = new HttpPost(rmConfig.get("authenticationUrl").getAsString());
            httpPost.setHeader("Content-Type", "application/json");
            httpPost.setEntity(new ByteArrayEntity(requestBody.toString().getBytes()));
            response = httpclient.execute(httpPost);
            HttpEntity entity = response.getEntity();
            responseBody = EntityUtils.toString(entity);
            if (response.getStatusLine().getStatusCode() == 200) {
            	logger.info("Authentication details : {}", responseBody);
            	return new Gson().fromJson(responseBody, JsonObject.class);
            } else {
            	logger.error("Authentication request failed : {}", responseBody);
            	return null;
            }
        } catch (Exception ex) {
        	logger.error("Exception while generating : {}", StackTrace.getMessage(ex));
        	return null;
        }
    }
    
    public JsonObject saveTransaction(String uid, String authenticationToken, JsonObject requestBody) {
        CloseableHttpClient httpclient = null;
        CloseableHttpResponse response = null; 
        String responseBody = null;
        JsonObject transactionResponse = new JsonObject();
        try {
            httpclient = validateSSL(httpclient);
            if (httpclient == null) {
               logger.error("HTTP client is null or invalid");
               return null;
            }
            HttpPost httpPost = new HttpPost(rmConfig.get("transactionUrl").getAsString());
            httpPost.setHeader("Content-Type", "application/json");
            httpPost.setHeader("Authorization", "Bearer " + authenticationToken);
            httpPost.setHeader("uid", uid);
            httpPost.setEntity(new ByteArrayEntity(requestBody.toString().getBytes()));
            response = httpclient.execute(httpPost);
            HttpEntity entity = response.getEntity();
            responseBody = EntityUtils.toString(entity);
            if (response.getStatusLine().getStatusCode() == 200) {
            	logger.info("Transaction request sent : {}", responseBody);
            } else {
            	logger.error("Transaction request failed : {}", responseBody);
            }
            transactionResponse.addProperty("status", response.getStatusLine().getStatusCode());
        	transactionResponse.addProperty("responseBody", responseBody);
        	return transactionResponse;
        } catch (Exception ex) {
        	logger.error("Exception while making HTTP POST request: {}", StackTrace.getMessage(ex));
        	return null;
        }
    }
    
    private CloseableHttpClient validateSSL(CloseableHttpClient httpClient) {
        int timeOut = 30000;
        try {
            RequestConfig config = RequestConfig.custom()
                .setConnectTimeout(timeOut * 1000)
                .setConnectionRequestTimeout(timeOut * 1000)
                .setSocketTimeout(timeOut * 1000).build();
            SSLContextBuilder sslBuilder = SSLContexts.custom();
            File file = new File(rmConfig.get("jksPath").getAsString());
            sslBuilder = sslBuilder.loadTrustMaterial(file, rmConfig.get("jksPassword").getAsString().toCharArray());
            SSLContext sslcontext = sslBuilder.build();
            SSLConnectionSocketFactory sslConSocFactory = new SSLConnectionSocketFactory(sslcontext, new NoopHostnameVerifier());
            HttpClientBuilder clientbuilder = HttpClients.custom().setSSLSocketFactory(sslConSocFactory);
            httpClient = clientbuilder.setDefaultRequestConfig(config).build();
        } catch (KeyManagementException ex) {
            logger.error("KeyManagementException while validating the SSL certificate : {}", StackTrace.getMessage(ex));
        } catch (NoSuchAlgorithmException ex) {
            logger.error("NoSuchAlgorithmException while validating the SSL certificate : {}", StackTrace.getMessage(ex));
        } catch (KeyStoreException ex) {
            logger.error("KeyStoreException while validating the SSL certificate : {}", StackTrace.getMessage(ex));
        } catch (CertificateException ex) {
            logger.error("CertificateException while validating the SSL certificate : {}", StackTrace.getMessage(ex));
        } catch (IOException ex) {
            logger.error("IOException while validating the SSL certificate : {}", StackTrace.getMessage(ex));
        } catch (Exception ex) {
            logger.error("Exception while validating the SSL certificate : {}", StackTrace.getMessage(ex));
        }
        return httpClient;
    }
}